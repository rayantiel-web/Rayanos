# RayanOS prototype

Open `index.html` in een browser. Geen installatie, geen internet nodig.

- `index.html`: structuur van de pagina
- `css/styles.css`: opmaak, donker en licht thema, responsief
- `js/app.js`: voorbeelddata, schermen, formulieren en chatsimulatie

Prototype: wat je toevoegt blijft bewaard tot je de pagina ververst. Blijvend opslaan komt met Supabase.
