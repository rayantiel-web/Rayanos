"""RayanOS API (FastAPI op Vercel). Python rekent en filtert, Supabase bewaart, de browser toont."""
import logging, os
from datetime import date, datetime, timedelta, timezone
from typing import Optional
from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import JSONResponse

log = logging.getLogger("rayanos")
app = FastAPI(title="RayanOS API")
WARN_DAYS, RED_DAYS, SOON_DAYS = 14, 30, 7


class Unavailable(Exception):
    pass


class Missing(Exception):
    def __init__(self, table):
        self.table = table


@app.exception_handler(Unavailable)
async def _unavailable(request, exc):
    return JSONResponse({"detail": "Database tijdelijk niet bereikbaar", "code": "db_unavailable"}, status_code=503)


def _client(token):
    url, key = os.getenv("SUPABASE_URL"), os.getenv("SUPABASE_ANON_KEY")
    if not url or not key:
        raise Unavailable("niet geconfigureerd")
    from supabase import create_client
    c = create_client(url, key)
    if token:
        c.postgrest.auth(token)  # RLS bepaalt wat deze gebruiker ziet
    return c


def rows(token, table, select="*", apply=None):
    try:
        q = _client(token).table(table).select(select)
        if apply:
            q = apply(q)
        return q.execute().data or []
    except Unavailable:
        raise
    except Exception as e:
        if "PGRST205" in str(e) or "does not exist" in str(e):
            raise Missing(table)
        log.exception("Databasefout bij tabel %s", table)  # details alleen in serverlog
        raise Unavailable("db")


def bearer(authorization):
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Niet ingelogd")
    return authorization[7:].strip()


def safe(token, table, select, miss, apply=None):
    try:
        return rows(token, table, select, apply)
    except Missing:
        miss.append(table)
        return None


def _dt(v):
    return datetime.fromisoformat(v.replace("Z", "+00:00")) if v else None


def _age_days(v, now):
    d = _dt(v)
    return (now - d).days if d else None


def project_health(p, tasks, now=None):
    """Uitlegbaar: geeft (kleur, reden). Rood > oranje > groen."""
    now = now or datetime.now(timezone.utc)
    if p.get("status") != "active":
        return "grey", "Project is niet actief"
    if any(t.get("status") != "done" and t.get("urgency") == "must" for t in tasks):
        return "red", "Kritieke open taak"
    due = date.fromisoformat(p["due_date"][:10]) if p.get("due_date") else None
    today = now.date()
    if due and due < today:
        return "red", "Deadline verlopen"
    age = _age_days(p.get("updated_at"), now)
    if age is not None and age > RED_DAYS:
        return "red", f"Al {age} dagen geen activiteit"
    if not p.get("next_action"):
        return "orange", "Geen volgende actie geregistreerd"
    if due and (due - today).days <= SOON_DAYS:
        return "orange", "Deadline nadert"
    if age is not None and age > WARN_DAYS:
        return "orange", f"{age} dagen geen activiteit"
    return "green", "Actief, volgende actie bekend, recente activiteit"


@app.get("/api/health")
def health():
    db = "not_configured"
    if os.getenv("SUPABASE_URL") and os.getenv("SUPABASE_ANON_KEY"):
        try:
            rows(None, "domains", "id", lambda q: q.limit(1))
            db = "connected"
        except Missing:
            db = "connected_schema_missing"
        except Unavailable:
            db = "unreachable"
    return {"status": "ok", "service": "rayanos-api", "database": db,
            "timestamp": datetime.now(timezone.utc).isoformat()}


@app.get("/api/dashboard/summary")
def summary(authorization: Optional[str] = Header(None)):
    t, miss, now = bearer(authorization), [], datetime.now(timezone.utc)
    tx = safe(t, "purchase_transactions", "amount_eur,payment_status", miss)
    pr = safe(t, "projects", "id,status", miss)
    tk = safe(t, "tasks", "status,completed_at", miss)
    total = lambda st: round(sum(float(x["amount_eur"] or 0) for x in tx if st is None or x["payment_status"] == st), 2)
    week = (now - timedelta(days=now.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    return {
        "registered_value": total(None) if tx is not None else None,
        "paid_amount": total("paid") if tx is not None else None,
        "outstanding_amount": total("outstanding") if tx is not None else None,
        "active_projects": sum(p["status"] == "active" for p in pr) if pr is not None else None,
        "open_tasks": sum(x["status"] != "done" for x in tk) if tk is not None else None,
        "completed_tasks_this_week": sum(bool(x["completed_at"]) and _dt(x["completed_at"]) >= week for x in tk) if tk is not None else None,
        "has_data": any(bool(v) for v in (tx, pr, tk)),
        "unavailable": miss,
        "last_updated": now.isoformat(),
    }


@app.get("/api/projects")
def projects(authorization: Optional[str] = Header(None)):
    t, miss = bearer(authorization), []
    pr = safe(t, "projects", "id,name,status,next_action,due_date,updated_at,domains(name)", miss, lambda q: q.order("updated_at", desc=True).limit(50))
    tk = safe(t, "tasks", "project_id,status,urgency", miss) or []
    out = []
    for p in pr or []:
        mine = [x for x in tk if x["project_id"] == p["id"]]
        h, why = project_health(p, mine)
        out.append({"id": p["id"], "name": p["name"], "domain": (p.get("domains") or {}).get("name"),
                    "status": p["status"], "progress": round(100 * sum(x["status"] == "done" for x in mine) / len(mine)) if mine else None,
                    "next_action": p.get("next_action"), "updated_at": p.get("updated_at"), "health": h, "health_reason": why})
    return {"items": out, "unavailable": miss}


def _listing(authorization, table, select, apply=None):
    t, miss = bearer(authorization), []
    data = safe(t, table, select, miss, apply)
    return {"items": data or [], "unavailable": miss}


@app.get("/api/tasks")
def tasks(status: Optional[str] = None, urgency: Optional[str] = None, project_id: Optional[str] = None,
          due_before: Optional[date] = None, authorization: Optional[str] = Header(None)):
    def ap(q):
        for col, val in (("status", status), ("urgency", urgency), ("project_id", project_id)):
            if val:
                q = q.eq(col, val)
        if due_before:
            q = q.lte("due_date", due_before.isoformat())
        return q.order("due_date")
    return _listing(authorization, "tasks", "id,title,status,urgency,due_date,project_id,completed_at", ap)


@app.get("/api/assets")
def assets(authorization: Optional[str] = Header(None)):
    return _listing(authorization, "assets", "id,name,category,brand,model,quantity,condition,ownership_status,purchase_transaction_id")


@app.get("/api/purchase-needs")
def purchase_needs(authorization: Optional[str] = Header(None)):
    return _listing(authorization, "purchase_needs", "id,name,status,reason,urgency,resume_trigger")
