/* Live-laag: haalt data uit /api en toont de status. Geen sleutels in de frontend. */
(function () {
  const L = window.LIVE = { ok: false, state: 'loading', s: null, at: null };
  let busy = false;
  const tz = { timeZone: 'Europe/Amsterdam', hour: '2-digit', minute: '2-digit' };
  const tok = () => sessionStorage.getItem('rayanos_token') || '';
  const T = { loading: 'Laden…', live: 'Live data', empty: 'Live, nog geen gegevens', auth: 'Demo data · niet ingelogd', db: 'Database niet verbonden', offline: 'Demo data · API niet bereikbaar' };
  async function api(p) {
    const r = await fetch('/api' + p, { headers: tok() ? { Authorization: 'Bearer ' + tok() } : {} });
    if (!r.ok) { const e = new Error('http'); e.status = r.status; throw e; }
    return r.json();
  }
  async function refresh() {
    if (busy) return; busy = true; L.state = 'loading'; paint();
    try {
      L.s = await api('/dashboard/summary'); L.at = new Date(L.s.last_updated); L.ok = true;
      L.state = L.s.has_data ? 'live' : 'empty';
    } catch (e) { L.ok = false; L.state = e.status === 401 ? 'auth' : e.status === 503 ? 'db' : 'offline'; }
    busy = false; paint(); if (window.render) window.render();
  }
  function paint() {
    const el = document.getElementById('live'); if (!el) return;
    const stale = L.at && Date.now() - L.at > 3e5;
    const miss = L.s && L.s.unavailable && L.s.unavailable.length ? '<div class="err">Nog niet beschikbaar: ' + L.s.unavailable.join(', ') + '</div>' : '';
    el.innerHTML = '<span class="pill ' + (L.state === 'live' ? 'done' : L.state === 'loading' ? 'wait' : 'must') + '">' + T[L.state] + '</span>' +
      '<div class="mu">' + new Date().toLocaleTimeString('nl-NL', tz) + ' Amsterdam</div>' +
      '<div class="mu">' + (L.at ? 'Vernieuwd ' + L.at.toLocaleTimeString('nl-NL', tz) : 'Nog niet vernieuwd') + '</div>' +
      (stale ? '<div class="err">Data is ouder dan 5 minuten</div>' : '') + miss +
      '<div class="fx"><button class="btn" id="lrefresh"' + (busy ? ' disabled' : '') + '>Vernieuwen</button><button class="btn" id="ltoken">Token</button></div>';
    document.getElementById('lrefresh').onclick = refresh;
    document.getElementById('ltoken').onclick = () => {
      const v = prompt('Plak je Supabase-toegangstoken (tijdelijk, tot er een loginscherm is):', '');
      if (v !== null) { sessionStorage.setItem('rayanos_token', v.trim()); refresh(); }
    };
  }
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });
  setInterval(() => { if (!document.hidden) refresh(); }, 60000);
  setInterval(() => { if (!document.hidden) paint(); }, 30000);
  setTimeout(refresh, 0);
})();
