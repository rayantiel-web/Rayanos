const $=s=>document.querySelector(s),eur=n=>'€'+n.toLocaleString('nl-NL');
const S={psub:'Alles',sf:'Open',focus:[false,false,false],wk:4,open:{Business:true},dom:'Business',v:'today',tab:'ov',f:'alles',cat:'alle',cmp:[{n:'Eerdere aankoop (schijven)',kg:210,p:370,st:'betaald'}],dec:{},log:[]};
const items=[
{n:'Cardiopakket',d:'2× Focus Fitness Row 2, Kettler-fiets (zonder meerprijs)',cat:'Cardio',p:45,st:'betaald',c:'Goed'},
{n:'Krachtpakket',d:'Focus Fitness Unit 4, power tower (grijs, werkt), buikspierbank',cat:'Kracht',p:175,st:'betaald',c:'Goed'},
{n:'Zipro Jacked fitnessbank',d:'In bezit',cat:'Kracht',p:30,st:'betaald',c:'Goed'},
{n:'Barbells',d:'2× 20 kg, 1× 15 kg',cat:'Gewichten',p:170,st:'betaald',c:'Goed'},
{n:'Halterschijven',d:'20 schijven, 210 kg, circa €1,76/kg',cat:'Gewichten',p:370,st:'betaald',c:'Goed'},
{n:'Wall balls',d:'3 stuks, gratis bij schijven, beperkt bruikbaar',cat:'Gewichten',p:0,st:'gratis',c:'Slecht'},
{n:'Functioneel trainingsframe',d:'±4,5 m breed, incl. 20 kg barbell en 9 m² rubbervloer',cat:'Frame',p:320,st:'betaald',c:'Goed'},
{n:'Rubberen gymvloer',d:'16 tegels 1×1 m + 3 halve, ±17,5 m², dikte onbekend',cat:'Vloer',p:223,st:'openstaand',c:'Goed'}];
const wait=[['Spiegels','pand bekend'],['Sprinttrack','pand en opslag bekend'],['Power cage','opslag bekend'],['Bokszak','pand bekend'],['Dumbbells','opslag bekend'],['Belichting','pand bekend']];
const done=['Cardiopakket binnen','Krachtpakket binnen','Fitnessbank binnen','Barbells binnen','Halterschijven binnen','Framepakket binnen','Wall balls meegekregen'];
const dec=[{id:'frame',t:'Framepakket: €650 aanbod',w:'Marktverkenning, geen verkoopbesluit. Frame wordt voorlopig behouden.',o:['Behouden','Verkopen']},{id:'bb',t:'Extra barbell (20 kg) verkopen?',w:'Staat nog niet te koop. Opbrengst verlaagt netto investering frame.',o:['Laten wachten','Te koop zetten']}];
const tot=()=>{if(window.LIVE&&LIVE.ok&&LIVE.s.paid_amount!=null)return{b:LIVE.s.paid_amount,o:LIVE.s.outstanding_amount,t:LIVE.s.registered_value};const b=items.filter(i=>i.st=='betaald'&&i.own!==false).reduce((a,i)=>a+i.p,0),o=items.filter(i=>i.st=='openstaand'&&i.own!==false).reduce((a,i)=>a+i.p,0);return{b,o,t:b+o}};
const pill=s=>({betaald:'<span class="pill done">✓ betaald</span>',openstaand:'<span class="pill must">● openstaand</span>',gratis:'<span class="pill wait">gratis</span>'}[s]);
function toast(t){const e=$('#toast');e.textContent=t;e.style.display='block';clearTimeout(toast.t);toast.t=setTimeout(()=>e.style.display='none',2600)}
function head(t,p,x=''){return `<div class="top"><div><h1>${t}</h1><p>${p}</p></div><div class="fx">${x}</div></div>`}
function today(){const T=tot(),r=188.5,off=r*(1-S.wk/10),dn=DOMS.map(([n,c])=>`<button class="dm" data-d="${n}"><span class="ic" style="background:${c}">${n[0]}</span>${n}</button>`).join('');
return `<div class="wg">
<button class="w" style="--t:${T.o?'var(--must)':'var(--done)'}" data-go="inv"><span class="wl">Openstaand</span><span class="wn" data-count="${T.o}" data-fmt="eur">${eur(T.o)}</span><span class="ws">${LIVE.ok?'Live data':(T.o?'Demo: rubbervloer':'Demo: alles betaald')}</span></button>
<button class="w" style="--t:var(--done)" data-wk2 aria-label="Weekdoelen ${S.wk} van 10, tik voor +1"><span class="wl">Weekdoelen</span><svg width="76" height="76" viewBox="0 0 76 76" aria-hidden="true"><circle cx="38" cy="38" r="30" fill="none" stroke="var(--s2)" stroke-width="9"/><circle cx="38" cy="38" r="30" fill="none" stroke="var(--done)" stroke-width="9" stroke-linecap="round" stroke-dasharray="${r}" stroke-dashoffset="${off}" transform="rotate(-90 38 38)"/><text x="38" y="45" text-anchor="middle" font-size="22" font-weight="700" fill="currentColor">${S.wk}</text></svg><span class="ws">van 10 · tik voor +1</span></button>
<section class="w m" style="--t:var(--ac)"><span class="wl">Focus vandaag (voorbeeld)</span><div>${FOC.map((t,i)=>`<button class="fr ${S.focus[i]?'dn':''}" data-focus="${i}" aria-pressed="${S.focus[i]}">${S.focus[i]?'✓':'○'} ${t}</button>`).join('')}</div></section>
<section class="w m" style="--t:var(--wait)"><span class="wl">Wacht bewust</span><div class="chips">${wait.map((w,i)=>`<button class="pill wait" data-wait="${i}">${w[0]}</button>`).join('')}</div><span class="ws">Tik op een item om te zien waarop het wacht.</span></section>
<button class="w" style="--t:var(--done)" data-go="project"><span class="wl">Sportschoolinrichting</span><span class="wn" style="font-size:1.5rem">Gezond</span><span class="ws">Volgende: vloer afrekenen</span></button>
<section class="w" style="--t:var(--prio)"><span class="wl">Spaardoel</span><span class="wn">€600</span><span class="ws">voorbeeld</span></section>
<section class="w m" style="--t:var(--done)"><span class="wl">Gedaan</span><div>${done.slice(-3).map(d=>`<div class="done">✓ ${d}</div>`).join('')}</div><span class="ws">${done.length} resultaten vastgelegd</span></section>
<section class="w m" style="--t:var(--mu)"><span class="wl">Domeinen</span><div class="dg">${dn}</div></section>
</div>`}
function domains(){const D=[['Persoonlijk','Spaardoel €600 (voorbeeld)',1],['Business','Sportschoolinrichting',1],['School','PB-MZ opleiding',1],['Sandbox','',0]];
return head('Domeinen','Vier plekken. Alles wat je invoert landt in één ervan.')+`<div class="doms">${D.map(d=>`<button class="dom" data-d="${d[0]}"><h3>${d[0]}</h3>${d[2]?`<p class="mu">${d[1]}</p><span class="pill done">1 project</span>`:`<div class="empty" style="margin-top:8px;padding:10px">Nog leeg. Zet een idee in de inbox via Chat.</div>`}</button>`).join('')}</div>`}
function project(){const T=tot(),t=S.tab;
const tabs=[['ov','Overzicht'],['dec','Besluiten'],['cmp','Gewichten vergelijken']];
let b='';
if(t=='ov')b=`<div class="grid"><div class="c s7"><h2>Context</h2><p>Nog geen definitief pand en beperkte opslag. Locatieafhankelijke aankopen wachten daarom. Gebruikte apparatuur in conditie Goed is prima: prijs, bruikbaarheid en veiligheid tellen.</p><p class="mu">Onbekend (mag onbekend blijven): hoogte en diepte frame, dikte vloer.</p></div>
<div class="c s5"><h2>Geld</h2><div class="row"><span>Betaald</span><b>${eur(T.b)}</b></div><div class="row"><span>Openstaand</span><b class="bad">${eur(T.o)}</b></div><div class="row"><span>Totaal</span><b>${eur(T.t)}</b></div></div>
<div class="c s12"><h2>Volgende actie</h2><p>Rubbervloer afrekenen (${eur(T.o)}).</p></div></div>`;
if(t=='dec')b=dec.map(d=>`<div class="c" style="margin-bottom:12px"><h3>${d.t}</h3><p class="mu">${d.w}</p>${S.dec[d.id]?`<span class="pill done">✓ Gekozen: ${S.dec[d.id]}</span> <small class="mu">Herzienbaar op elk moment</small>`:`<div class="fx">${d.o.map(o=>`<button class="btn" data-dec="${d.id}|${o}">${o}</button>`).join('')}<button class="btn" data-dec="${d.id}|Later beslissen">Later beslissen</button></div>`}</div>`).join('');
if(t=='cmp'){b=`<div class="c scroll"><table class="tbl"><tr class="mu"><td>Optie</td><td>kg</td><td>Prijs</td><td>€/kg</td></tr>${S.cmp.map(x=>`<tr><td>${x.n}<br><small class="mu">${x.st=='betaald'?'gekocht':'advertentie: beschikbaarheid niet gegarandeerd'}</small></td><td>${x.kg}</td><td>${eur(x.p)}</td><td><b>${(x.p/x.kg).toFixed(2).replace('.',',')}</b></td></tr>`).join('')}</table></div>`}
return head('Sportschoolinrichting','Business · Actief','<span class="pill done">Gezond</span>')+`<div class="tabs">${tabs.map(x=>`<button data-t="${x[0]}" aria-pressed="${t==x[0]}">${x[1]}</button>`).join('')}</div>`+b}
function inv(){const T=tot();let L=items.filter(i=>(S.f=='alles'||i.st==S.f)&&(S.cat=='alle'||i.cat==S.cat));const cats=['alle',...new Set(items.map(i=>i.cat))];
return head('Inventaris','Wat je bezit, wat betaald is en wat nog openstaat. Demo data: nog niet uit Supabase.','<button class="btn pri" data-add>+ Toevoegen</button>')+`<div class="grid" style="margin-bottom:14px"><div class="c s4"><small class="mu">Betaald</small><div class="big" data-count="${T.b}" data-fmt="eur">${eur(T.b)}</div></div><div class="c s4"><small class="mu">Openstaand</small><div class="big bad" data-count="${T.o}" data-fmt="eur">${eur(T.o)}</div></div><div class="c s4"><small class="mu">Totaal geregistreerd</small><div class="big" data-count="${T.t}" data-fmt="eur">${eur(T.t)}</div></div></div>
<div class="fx">${['alles','betaald','openstaand','gratis'].map(f=>`<button class="chip" data-f="${f}" aria-pressed="${S.f==f}">${f}</button>`).join('')}<select id="cs" aria-label="Categorie">${cats.map(c=>`<option ${S.cat==c?'selected':''}>${c}</option>`).join('')}</select></div>
<div class="c">${L.length?L.map(i=>`<div class="row"><div><b>${i.n}</b> <small class="mu">${i.cat} · ${i.c}</small><br><small class="mu">${i.d}</small></div><div style="text-align:right">${eur(i.p)}<br>${pill(i.st)}${i.own===false?' <span class="pill wait">niet opgehaald</span>':''}</div></div>`).join(''):'<div class="empty">Geen items bij dit filter. Kies “alles” of een andere categorie.</div>'}</div>
<p class="mu">Eigen gewicht: 75 kg barbells (3×20, 1×15) + 210 kg schijven. Opbrengst van verkochte frame-onderdelen verlaagt later de netto investering.</p>`}
const DOMS=[['Persoonlijk','var(--prio)'],['Business','var(--ac)'],['School','var(--wait)'],['Sandbox','var(--done)']];
const quips=['Eén ding tegelijk. De rest wacht netjes.','Wachten is ook een besluit.','Een goed idee loopt niet weg, het wacht op zijn moment.','Klein, af, volgende.','Je hoeft niet alles te onthouden. Daar is dit voor.','Eerst kijken wat al gedaan is.'];
const hello=()=>{const h=new Date().getHours();return h<6?'Nog wakker':h<12?'Goedemorgen':h<18?'Goedemiddag':'Goedenavond'};
const quip=()=>quips[Math.floor(Date.now()/864e5)%quips.length];
const reduce=()=>matchMedia('(prefers-reduced-motion:reduce)').matches;
function closeNav(){$('#nav').classList.remove('open');$('#scrim').classList.remove('on')}
function buildNav(){$('#tree').innerHTML=DOMS.map(([n,c])=>`<button data-d="${n}" ${S.v=='dom'&&S.dom==n?'aria-current="page"':''}><span class="dot" style="background:${c}"></span>${n}</button>`+(n=='Business'&&S.open.Business?'<div class="sub"><button data-v="project">Sportschoolinrichting</button><button data-v="inv">Inventaris</button></div>':'')).join('');
document.querySelectorAll('nav [data-v]').forEach(b=>b.ariaCurrent=b.dataset.v==S.v?'page':null)}
function dom(){if(S.dom=='Persoonlijk')return domP();if(S.dom=='School')return domS();const n=S.dom,ex=null;
return head(n,n=='Business'?'Eén project loopt. Kies waar je mee verder wilt.':'Nog weinig te zien. Zeg iets in de chat, dan landt het hier.')+(n=='Business'?`<div class="doms"><button class="dom" data-v="project"><h3>Sportschoolinrichting</h3><p class="mu">Volgende: vloer afrekenen</p><span class="pill done">Gezond</span></button><button class="dom" data-v="inv"><h3>Inventaris</h3><p class="mu">${items.length} items, ${eur(tot().t)} geregistreerd</p></button></div>`:ex?`<div class="c">${ex} <small class="mu">(voorbeeld)</small></div>`:'<div class="empty">Leeg. Dat is prima: ideeën mogen hier rustig rijpen.</div>')}
function countUp(){document.querySelectorAll('[data-count]').forEach(e=>{const t=+e.dataset.count,f=e.dataset.fmt=='eur'?eur:n=>n+' resultaten';if(reduce()){e.textContent=f(t);return}const s=performance.now();(function k(now){const p=Math.min(1,(now-s)/700);e.textContent=f(Math.round(t*(1-Math.pow(1-p,3))));if(p<1)requestAnimationFrame(k)})(s)})}
function spark(x,y){if(reduce())return;for(let i=0;i<12;i++){const s=document.createElement('span');s.textContent='✓';Object.assign(s.style,{position:'fixed',left:x+'px',top:y+'px',color:['var(--done)','var(--ac)','var(--prio)'][i%3],fontWeight:700,pointerEvents:'none',zIndex:40});document.body.appendChild(s);const a=Math.PI*2*i/12,d=40+Math.random()*40;s.animate([{transform:'translate(0,0) scale(1)',opacity:1},{transform:`translate(${Math.cos(a)*d}px,${Math.sin(a)*d}px) scale(.4)`,opacity:0}],{duration:650,easing:'ease-out'}).onfinish=()=>s.remove()}}
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
let F={};
const opt=(a,v)=>a.map(([k,l])=>`<option value="${k}" ${k==v?'selected':''}>${l}</option>`).join('');
function openAdd(){F={step:1,name:'',cat:'Kracht',src:'particulier',p:'',pay:'betaald',cond:'Goed',own:'ja',kg:'',note:'',err:{}};drawF();$('#ov2').classList.add('on')}
function readF(){const g=id=>document.getElementById(id);if(!g('f-name'))return;F.name=g('f-name').value.trim();F.cat=g('f-cat').value;F.src=g('f-src').value;F.cond=g('f-cond').value;F.own=g('f-own').value;F.note=g('f-note').value.trim();if(g('f-p')){F.p=g('f-p').value;F.pay=g('f-pay').value}if(g('f-kg'))F.kg=g('f-kg').value}
function drawF(){const f=F,free=f.src=='gratis',L=(id,t)=>`<label class="fl" for="${id}">${t}</label>`,E=k=>f.err[k]?`<div class="err">${f.err[k]}</div>`:'';let b;
if(f.step==2){const p=free?0:+f.p,k=+f.kg;b=`<div class="prop"><b>Dit sla ik op, na jouw bevestiging</b><dl><dt>Plek</dt><dd>Business → Sportschoolinrichting → Inventaris</dd><dt>Item</dt><dd>${esc(f.name)} (${f.cat})</dd><dt>Prijs</dt><dd>${free?'gratis':eur(p)+', '+f.pay}</dd>${k&&p?`<dt>Per kg</dt><dd>€${(p/k).toFixed(2).replace('.',',')}</dd>`:''}<dt>Conditie</dt><dd>${f.cond}</dd><dt>Bezit</dt><dd>${f.own=='ja'?'In bezit':'Gereserveerd, nog niet opgehaald'}</dd>${f.note?`<dt>Notitie</dt><dd>${esc(f.note)}</dd>`:''}</dl>${f.own!='ja'?'<p class="mu">Particuliere verkoop: beschikbaarheid is niet gegarandeerd. Telt nog niet mee in de totalen.</p>':''}<div class="fx"><button class="btn pri" data-fsave>Opslaan</button><button class="btn" data-fedit>Aanpassen</button></div></div>`}
else b=L('f-name','Wat is het? *')+`<input type="text" id="f-name" value="${esc(f.name)}" placeholder="Bijv. Dumbbellset">${E('name')}`
+L('f-cat','Categorie')+`<select id="f-cat">${opt(['Cardio','Kracht','Gewichten','Frame','Vloer','Overig'].map(x=>[x,x]),f.cat)}</select>`
+L('f-src','Hoe kom je eraan?')+`<select id="f-src">${opt([['particulier','Tweedehands van particulier'],['zakelijk','Nieuw of zakelijk'],['gratis','Gratis gekregen']],f.src)}</select>`
+(free?'':L('f-p','Prijs in euro *')+`<input type="number" id="f-p" min="0" step="0.01" inputmode="decimal" value="${esc(f.p)}">${E('p')}`+L('f-pay','Betaling')+`<select id="f-pay">${opt([['betaald','Betaald'],['openstaand','Nog openstaand']],f.pay)}</select>`)
+(f.cat=='Gewichten'?L('f-kg','Totaal gewicht in kg (optioneel)')+`<input type="number" id="f-kg" min="0" step="0.5" inputmode="decimal" value="${esc(f.kg)}">${E('kg')}`:'')
+L('f-cond','Conditie')+`<select id="f-cond">${opt(['Goed','Redelijk','Slecht','Onbekend'].map(x=>[x,x]),f.cond)}</select>`
+L('f-own','Heb je het al?')+`<select id="f-own">${opt([['ja','Ja, in bezit'],['nee','Nee, gereserveerd of nog te halen']],f.own)}</select>`
+L('f-note','Notitie (optioneel)')+`<input type="text" id="f-note" value="${esc(f.note)}" placeholder="Maten, merk, bijzonderheden">`
+'<div class="fx" style="margin-top:14px"><button class="btn pri" data-fcheck>Controleer</button></div>';
$('#form').innerHTML=`<div style="display:flex;justify-content:space-between;align-items:center"><h2 style="margin:0">Item toevoegen</h2><button class="btn" data-fx>Sluiten</button></div><p class="proto">Prototype: opgeslagen tot je de pagina ververst.</p>`+b}
function saveF(cx,cy){const f=F,free=f.src=='gratis';items.push({n:f.name,d:f.note||'Geen notitie',cat:f.cat,p:free?0:+f.p,st:free?'gratis':f.pay,c:f.cond,own:f.own=='ja'});$('#ov2').classList.remove('on');S.f='alles';S.cat='alle';render();toast('Toegevoegd aan inventaris: '+f.name);spark(cx,cy)}
const FOC=['Rubbervloer afrekenen','Framepakket-besluit bekijken','Eén idee vastleggen in de chat'];
const attn=()=>{const a=[],T=tot();SCH.filter(i=>!i.done&&dl(i.due)<=3).forEach(i=>a.push({t:i.t,s:'School · '+rel(i.due),v:'',l:i.urg=='Moet'?'must':'prio',go:['dom','School']}));if(T.o>0)a.push({t:'Rubbervloer betalen',s:'Sportschoolinrichting',v:eur(T.o),l:'must',go:['inv']});if(!S.dec.frame)a.push({t:'Besluit: framepakket €650',s:'Alleen verkennen, geen haast',v:'',l:'prio',go:['project','dec']});return a};
const attnRows=()=>{const a=attn();return a.length?a.map(x=>`<div class="row"><div>${x.t}<br><small class="mu">${x.s}</small></div><div style="text-align:right"><span class="pill ${x.l}">${x.l=='must'?'Moet':'Prioriteit'}</span>${x.v?'<br><b>'+x.v+'</b>':''}<br><button class="btn" data-go="${x.go.join('|')}">Open</button></div></div>`).join(''):'<div class="empty">Niets vraagt aandacht. Goed bezig.</div>'};
const bell=()=>{const n=attn().length;return `<button class="btn bell" data-bell aria-haspopup="dialog" aria-label="Aandachtspunten: ${n}">${n?'Aandacht <span class="badge">'+n+'</span>':'<span class="ok">✓ Rustig</span>'}</button>`};
function drawPop(){$('#pop').innerHTML=`<div style="display:flex;justify-content:space-between;align-items:center"><h2 style="margin:0">Aandachtspunten</h2><button class="btn" data-pclose>Sluiten</button></div>${attnRows()}<p class="mu" style="margin:10px 0 0;font-style:italic">${quip()}</p>`}
function updFab(){const n=attn().length,f=$('#fbell');f.innerHTML='🔔<span class="lbl"> Aandacht</span>'+(n?' <span class="badge">'+n+'</span>':' <span class="ok">✓</span>');f.setAttribute('aria-label','Aandachtspunten: '+n);const t=document.querySelector('nav [data-v=today]');if(t)t.innerHTML='Vandaag'+(n?' <span class="badge">'+n+'</span>':'')}
function closePop(){const p=$('#pop');if(p)p.hidden=true}
document.addEventListener('click',e=>{if(!e.target.closest('#pop,[data-bell]'))closePop()});
const dl=d=>Math.round((new Date(d+'T00:00')-new Date().setHours(0,0,0,0))/864e5);
const rel=d=>{const n=dl(d);return n<0?Math.abs(n)+' dagen te laat':n==0?'vandaag':n==1?'morgen':'over '+n+' dagen'};
const fd=d=>new Date(d+'T00:00').toLocaleDateString('nl-NL',{day:'numeric',month:'short'});
const dd=n=>{const d=new Date();d.setDate(d.getDate()+n);return d.toLocaleDateString('sv-SE')};
const PERS=[{sub:'Financiën',type:'Doel',t:'€600 sparen',amt:600,note:'voorbeeld',done:false},{sub:'Routines',type:'Routine',t:'Wekelijkse RayanOS-review',freq:'Wekelijks',note:'voorbeeld',done:false}];
const SCH=[{t:'Reflectieverslag',vak:'',type:'Opdracht',due:dd(5),urg:'Prioriteit',note:'voorbeeld',done:false},{t:'Toets voorbereiden',vak:'',type:'Toets',due:dd(12),urg:'Moet',note:'voorbeeld',done:false}];
const FORMS={pers:{title:'Persoonlijk toevoegen',place:f=>'Persoonlijk → '+f.sub,fields:[
{k:'sub',l:'Onderwerp',o:['Financiën','Gezondheid','Ontwikkeling','Routines','Levensdoelen','Agenda']},
{k:'type',l:'Wat is het?',o:['Doel','Taak','Routine','Notitie']},
{k:'t',l:'Titel *',req:1,ph:'Bijv. €600 sparen'},
{k:'amt',l:'Bedrag in euro (optioneel)',n:1,show:f=>f.sub=='Financiën'},
{k:'freq',l:'Hoe vaak?',o:['Dagelijks','Wekelijks','Maandelijks'],show:f=>f.type=='Routine'},
{k:'due',l:'Deadline (optioneel)',d:1,show:f=>f.type=='Doel'||f.type=='Taak'},
{k:'note',l:'Notitie (optioneel)'}]},
school:{title:'Opdracht toevoegen',place:()=>'School → Opdrachten',fields:[
{k:'t',l:'Naam *',req:1,ph:'Bijv. Verslag week 3'},
{k:'vak',l:'Vak of module (optioneel)'},
{k:'type',l:'Soort',o:['Opdracht','Toets','Examen','Stage','Certificering']},
{k:'due',l:'Deadline *',d:1,req:1},
{k:'urg',l:'Hoe belangrijk?',o:['Moet','Prioriteit','Kans']},
{k:'note',l:'Notitie (optioneel)'}]}};
let G={};
function openG(k){const f={};FORMS[k].fields.forEach(q=>f[q.k]=q.o?q.o[0]:'');if(k=='pers'&&S.psub!='Alles')f.sub=S.psub;G={kind:k,step:1,f,err:{}};drawG();$('#ov2').classList.add('on')}
function readG(){FORMS[G.kind].fields.forEach(q=>{const e=document.getElementById('g-'+q.k);if(e)G.f[q.k]=e.value.trim()})}
function drawG(){const C=FORMS[G.kind],f=G.f,vis=C.fields.filter(q=>!q.show||q.show(f));let b;
if(G.step==2)b=`<div class="prop"><b>Dit sla ik op, na jouw bevestiging</b><dl><dt>Plek</dt><dd>${C.place(f)}</dd>${vis.filter(q=>f[q.k]).map(q=>`<dt>${q.l.replace(/ ?(\*|\(optioneel\))/g,'')}</dt><dd>${esc(q.k=='amt'?eur(+f[q.k]):q.d?fd(f[q.k])+', '+rel(f[q.k]):f[q.k])}</dd>`).join('')}</dl><div class="fx"><button class="btn pri" data-gsave>Opslaan</button><button class="btn" data-gedit>Aanpassen</button></div></div>`;
else b=vis.map(q=>`<label class="fl" for="g-${q.k}">${q.l}</label>`+(q.o?`<select id="g-${q.k}">${opt(q.o.map(v=>[v,v]),f[q.k])}</select>`:`<input id="g-${q.k}" type="${q.d?'date':q.n?'number':'text'}" ${q.n?'min="0" step="0.01" inputmode="decimal"':''} value="${esc(f[q.k])}" placeholder="${q.ph||''}">`)+(G.err[q.k]?`<div class="err">${G.err[q.k]}</div>`:'')).join('')+'<div class="fx" style="margin-top:14px"><button class="btn pri" data-gcheck>Controleer</button></div>';
$('#form').innerHTML=`<div style="display:flex;justify-content:space-between;align-items:center"><h2 style="margin:0">${C.title}</h2><button class="btn" data-fx>Sluiten</button></div><p class="proto">Prototype: opgeslagen tot je de pagina ververst.</p>`+b}
function saveG(cx,cy){const C=FORMS[G.kind],f={};C.fields.filter(q=>!q.show||q.show(G.f)).forEach(q=>f[q.k]=G.f[q.k]);f.done=false;if(f.amt!==undefined)f.amt=f.amt===''?null:+f.amt;(G.kind=='pers'?PERS:SCH).push(f);$('#ov2').classList.remove('on');render();toast('Toegevoegd: '+f.t);spark(cx,cy)}
function domP(){const subs=['Alles','Financiën','Gezondheid','Ontwikkeling','Routines','Levensdoelen','Agenda'],L=PERS.map((x,i)=>({...x,i})).filter(x=>S.psub=='Alles'||x.sub==S.psub);
return head('Persoonlijk','Alles wat privé is, per onderwerp.','<button class="btn pri" data-gadd="pers">+ Toevoegen</button>')+`<div class="tabs">${subs.map(x=>`<button data-psub="${x}" aria-pressed="${S.psub==x}">${x}${x=='Alles'?'':' ('+PERS.filter(p=>p.sub==x).length+')'}</button>`).join('')}</div><div class="c">${L.length?L.map(x=>`<div class="row">${x.type=='Doel'||x.type=='Taak'?`<button class="ck ${x.done?'on':''}" data-gdone="pers|${x.i}" aria-label="Afronden: ${esc(x.t)}">${x.done?'✓':''}</button>`:''}<div style="flex:1;min-width:0"><span class="${x.done?'mu':''}" style="${x.done?'text-decoration:line-through':''}">${esc(x.t)}</span><br><small class="mu">${x.sub} · ${x.type}${x.amt!=null?' · '+eur(x.amt):''}${x.freq?' · '+x.freq:''}${x.due?' · '+fd(x.due)+', '+rel(x.due):''}${x.note?' · '+esc(x.note):''}</small></div></div>`).join(''):`<div class="empty">Nog niets bij ${S.psub=='Alles'?'Persoonlijk':S.psub}. Tik op + Toevoegen.</div>`}</div>`}
function domS(){const all=SCH.map((x,i)=>({...x,i})),open=all.filter(x=>!x.done),L=all.filter(x=>S.sf=='Alles'||(S.sf=='Open')!=x.done).sort((a,b)=>a.due<b.due?-1:1);
return head('School',`${open.length} open · ${open.filter(x=>dl(x.due)<=7).length} binnen 7 dagen`,'<button class="btn pri" data-gadd="school">+ Opdracht toevoegen</button>')+`<div class="tabs">${['Open','Klaar','Alles'].map(x=>`<button data-sf="${x}" aria-pressed="${S.sf==x}">${x}</button>`).join('')}</div><div class="c">${L.length?L.map(x=>`<div class="row"><button class="ck ${x.done?'on':''}" data-gdone="sch|${x.i}" aria-label="Afronden: ${esc(x.t)}">${x.done?'✓':''}</button><div style="flex:1;min-width:0"><span style="${x.done?'text-decoration:line-through;color:var(--mu)':''}">${esc(x.t)}</span><br><small class="mu">${x.vak?esc(x.vak)+' · ':''}${x.type} · ${fd(x.due)}, ${rel(x.due)}${x.note?' · '+esc(x.note):''}</small></div><span class="pill ${x.urg=='Moet'?'must':x.urg=='Prioriteit'?'prio':'wait'}">${x.urg}</span></div>`).join(''):`<div class="empty">${S.sf=='Klaar'?'Nog niets afgerond. Vink een opdracht af en hij komt hier.':'Geen open opdrachten. Tik op + Opdracht toevoegen.'}</div>`}</div>`}
function render(){buildNav();updFab();$('#main').innerHTML={today,domains,project,inv,dom}[S.v]();countUp();scrollTo(0,0);closeNav();closePop()}
document.addEventListener('click',e=>{const x=e.target.closest('button');if(!x)return;const r=x.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;
if(x.dataset.v){S.v=x.dataset.v;render()}
else if(x.dataset.d){const d=x.dataset.d,same=S.v=='dom'&&S.dom==d;S.dom=d;S.open[d]=same?!S.open[d]:true;S.v='dom';render()}
else if('add' in x.dataset)openAdd();
else if('fx' in x.dataset)$('#ov2').classList.remove('on');
else if('fcheck' in x.dataset){readF();const free=F.src=='gratis',er={};if(!F.name)er.name='Geef het item een naam.';if(!free&&(F.p===''||isNaN(+F.p)||+F.p<0))er.p='Vul een bedrag in (0 of hoger).';if(F.kg!==''&&(isNaN(+F.kg)||+F.kg<=0))er.kg='Vul een gewicht groter dan 0 in, of laat leeg.';F.err=er;if(!Object.keys(er).length)F.step=2;drawF()}
else if('fedit' in x.dataset){F.step=1;drawF()}
else if('fsave' in x.dataset){saveF(cx,cy)}
else if('bell' in x.dataset){if($('#pop').hidden){drawPop();$('#pop').hidden=false}else closePop()}
else if('pclose' in x.dataset)closePop();
else if(x.dataset.go){const[v,t]=x.dataset.go.split('|');S.v=v;if(v=='dom'&&t){S.dom=t;S.open[t]=true}else if(t)S.tab=t;render()}
else if(x.dataset.focus!==undefined){const i=+x.dataset.focus;S.focus[i]=!S.focus[i];render();if(S.focus[i])spark(cx,cy);if(S.focus.every(Boolean))toast('Alle drie gedaan. Dag gewonnen.')}
else if('wk2' in x.dataset){S.wk=(S.wk+1)%11;render();spark(cx,cy)}
else if(x.dataset.wait!==undefined){const w=wait[+x.dataset.wait];toast(w[0]+' wacht op: '+w[1])}
else if(x.dataset.gadd){openG(x.dataset.gadd)}
else if('gcheck' in x.dataset){readG();const C=FORMS[G.kind],er={};C.fields.filter(q=>!q.show||q.show(G.f)).forEach(q=>{const v=G.f[q.k];if(q.req&&!v)er[q.k]='Dit veld is nodig.';else if(q.n&&v!==''&&(isNaN(+v)||+v<0))er[q.k]='Vul een bedrag van 0 of hoger in.'});G.err=er;if(!Object.keys(er).length)G.step=2;drawG()}
else if('gedit' in x.dataset){G.step=1;drawG()}
else if('gsave' in x.dataset){saveG(cx,cy)}
else if(x.dataset.gdone){const[k,i]=x.dataset.gdone.split('|'),a=k=='pers'?PERS:SCH;a[+i].done=!a[+i].done;render();if(a[+i].done){spark(cx,cy);toast('Afgerond: '+a[+i].t)}}
else if(x.dataset.psub){S.psub=x.dataset.psub;render()}
else if(x.dataset.sf){S.sf=x.dataset.sf;render()}
else if(x.dataset.wk){const i=+x.dataset.wk;S.wk=(i+1==S.wk)?i:i+1;render();spark(cx,cy)}
else if(x.id=='burger'){$('#nav').classList.add('open');$('#scrim').classList.add('on')}
else if(x.dataset.t){S.tab=x.dataset.t;render()}
else if(x.dataset.f){S.f=x.dataset.f;render()}
else if(x.dataset.dec){const[a,b]=x.dataset.dec.split('|');S.dec[a]=b;toast('Besluit vastgelegd: '+b+'. Weer iets minder in je hoofd.');render();spark(cx,cy)}
else if('chat' in x.dataset){openChat()}
else if(x.id=='thm'){const r=document.documentElement;r.dataset.theme=r.dataset.theme=='dark'?'light':'dark'}
else if(x.id=='cx')$('#ov').classList.remove('on');
else if(x.id=='ex'){$('#msg').value='Ik heb 100 kg gewichten gevonden voor €160';send()}
else if(x.id=='send')send();
else if(x.dataset.ok){spark(cx,cy);confirmProp()}
else if(x.dataset.edit){const p=prompt('Nieuwe prijs in euro:',cur.p);const n=parseFloat(p);if(n>0){cur.p=n;propose()}else if(p!==null)toast('Vul een getal groter dan 0 in')}
else if(x.dataset.no){add('bub','Niets opgeslagen. Er is niets gewijzigd.');cur=null}});
document.addEventListener('change',e=>{if(e.target.id=='cs'){S.cat=e.target.value;render()}if(e.target.id=='f-src'||e.target.id=='f-cat'){readF();drawF()}if(/^g-/.test(e.target.id)){readG();drawG()}});
document.addEventListener('keydown',e=>{if(e.key=='c'&&!/INPUT|SELECT|TEXTAREA/.test(e.target.tagName)&&!e.metaKey&&!e.ctrlKey){e.preventDefault();openChat()}if(e.key=='Escape'){closePop();closeNav();$('#ov2').classList.remove('on')}if(e.key=='Escape')$('#ov').classList.remove('on');if(e.key=='Enter'&&e.target.id=='msg')send()});
$('#scrim').addEventListener('click',closeNav);$('#ov').addEventListener('click',e=>{if(e.target.id=='ov')e.target.classList.remove('on')});
let cur=null;
function add(c,h){const d=document.createElement('div');d.className=c;d.innerHTML=h;$('#log').appendChild(d);d.scrollIntoView({block:'nearest'})}
function openChat(){$('#ov').classList.add('on');if(!$('#log').children.length)add('bub','Vertel maar. Ik leg niets vast zonder dat jij het eerst ziet.');$('#msg').focus()}
function send(){const t=$('#msg').value.trim();if(!t)return;$('#msg').value='';add('bub me',t.replace(/</g,'&lt;'));
const kg=(t.match(/(\d+[.,]?\d*)\s*kg/i)||[])[1],p=(t.match(/€\s*(\d+[.,]?\d*)|(\d+[.,]?\d*)\s*(euro|€)/i)||[]);const pr=p[1]||p[2];
if(!kg||!pr){add('bub','Ik mis een gewicht (kg) of een prijs (€). Probeer: “120 kg schijven voor €190”. Er is niets opgeslagen.');return}
cur={kg:parseFloat(kg.replace(',','.')),p:parseFloat(pr.replace(',','.'))};propose()}
function propose(){const k=cur.p/cur.kg,f=n=>n.toFixed(2).replace('.',',');
add('bub',`Dat is <b>€${f(k)} per kg</b>. Je eerdere aankoop was €1,76 per kg (${k<1.76?'€'+f(1.76-k)+' lager':'€'+f(k-1.76)+' hoger'}); richtprijs €1,50 (${k>1.5?'€'+f(k-1.5)+' erboven':'onder richtprijs'}). Transport, conditie en beschikbaarheid ontbreken nog.`);
add('prop',`<b>Dit sla ik op, na jouw bevestiging</b><dl><dt>Plek</dt><dd>Business → Sportschoolinrichting → Gewichten</dd><dt>Type</dt><dd>Vergelijkingsitem (particuliere advertentie)</dd><dt>Gewicht</dt><dd>${cur.kg} kg</dd><dt>Prijs</dt><dd>${eur(cur.p)}</dd><dt>Onbekend</dt><dd>transport, conditie, beschikbaarheid</dd></dl><div class="fx"><button class="btn pri" data-ok>Opslaan</button><button class="btn" data-edit>Prijs aanpassen</button><button class="btn" data-no>Niet opslaan</button></div>`)}
function confirmProp(){if(!cur)return;S.cmp.push({n:'Advertentie '+cur.kg+' kg',kg:cur.kg,p:cur.p,st:'advertentie'});add('bub','Opgeslagen als vergelijkingsitem. Gelogd als AI-wijziging, terug te draaien via archiveren.');cur=null;toast('Opgeslagen in Gewichten vergelijken');if(S.v=='project')render()}
render();
