-- RayanOS MVP. NIET automatisch uitgevoerd: plak in Supabase > SQL Editor na controle.
-- Alleen toevoegen, geen DROP TABLE/DELETE. Bestaande public.domains blijft staan (kolom user_id wordt toegevoegd).
create table if not exists public.domains (id uuid primary key default gen_random_uuid(), name text not null, created_at timestamptz not null default now());
alter table public.domains add column if not exists user_id uuid default auth.uid();

create table if not exists public.projects (id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid(),
  domain_id uuid references public.domains(id), name text not null,
  status text not null default 'planned' check (status in ('planned','active','waiting','paused','stopped','done')),
  next_action text, due_date date, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.tasks (id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid(),
  project_id uuid references public.projects(id), title text not null,
  status text not null default 'open' check (status in ('open','done')),
  urgency text not null default 'opportunity' check (urgency in ('must','priority','opportunity','waiting','routine')),
  due_date date, completed_at timestamptz, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.purchase_transactions (id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid(),
  project_id uuid references public.projects(id), description text not null, amount_eur numeric(10,2) not null check (amount_eur >= 0),
  payment_status text not null check (payment_status in ('paid','outstanding')), purchased_at timestamptz, created_at timestamptz not null default now());
create table if not exists public.asset_groups (id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid(),
  project_id uuid references public.projects(id), name text not null);
create table if not exists public.assets (id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid(),
  asset_group_id uuid references public.asset_groups(id), purchase_transaction_id uuid references public.purchase_transactions(id),
  name text not null, category text, brand text, model text, quantity int not null default 1, condition text,
  ownership_status text not null default 'owned', created_at timestamptz not null default now());
create table if not exists public.purchase_needs (id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid(),
  project_id uuid references public.projects(id), name text not null, status text not null default 'waiting', reason text,
  urgency text, resume_trigger text, created_at timestamptz not null default now());
create table if not exists public.decisions (id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid(),
  project_id uuid references public.projects(id), title text not null, reason text, decided_at timestamptz, review_trigger text, outcome text,
  created_at timestamptz not null default now());

create or replace function public.set_updated_at() returns trigger language plpgsql as $$ begin new.updated_at = now(); return new; end $$;
drop trigger if exists trg_projects_updated on public.projects; create trigger trg_projects_updated before update on public.projects for each row execute function public.set_updated_at();
drop trigger if exists trg_tasks_updated on public.tasks; create trigger trg_tasks_updated before update on public.tasks for each row execute function public.set_updated_at();

-- Row Level Security: iedere gebruiker ziet alleen eigen rijen.
do $$ declare t text; begin
  foreach t in array array['domains','projects','tasks','purchase_transactions','asset_groups','assets','purchase_needs','decisions'] loop
    execute format('alter table public.%I enable row level security', t);
    if not exists (select 1 from pg_policies where schemaname='public' and tablename=t and policyname='own_rows') then
      execute format('create policy own_rows on public.%I for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid())', t);
    end if;
  end loop;
end $$;
