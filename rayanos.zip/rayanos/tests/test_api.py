import os, sys
from datetime import datetime, timezone
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "api"))
import index
from fastapi.testclient import TestClient

c = TestClient(index.app)
H = {"Authorization": "Bearer test"}
NOW = datetime(2026, 11, 16, tzinfo=timezone.utc)


def test_health_without_config(monkeypatch):
    monkeypatch.delenv("SUPABASE_URL", raising=False)
    r = c.get("/api/health").json()
    assert r["status"] == "ok" and r["database"] == "not_configured"


def test_summary_needs_login():
    assert c.get("/api/dashboard/summary").status_code == 401


def test_summary_values(monkeypatch):
    data = {"purchase_transactions": [{"amount_eur": 1110, "payment_status": "paid"}, {"amount_eur": 223, "payment_status": "outstanding"}],
            "projects": [{"id": "1", "status": "active"}], "tasks": []}
    monkeypatch.setattr(index, "rows", lambda t, tbl, s="*", a=None: data[tbl])
    r = c.get("/api/dashboard/summary", headers=H).json()
    assert (r["paid_amount"], r["outstanding_amount"], r["registered_value"]) == (1110, 223, 1333) and r["has_data"]


def test_empty_database(monkeypatch):
    monkeypatch.setattr(index, "rows", lambda *a, **k: [])
    r = c.get("/api/dashboard/summary", headers=H).json()
    assert r["has_data"] is False and r["registered_value"] == 0


def test_missing_tables(monkeypatch):
    def boom(t, tbl, s="*", a=None):
        raise index.Missing(tbl)
    monkeypatch.setattr(index, "rows", boom)
    r = c.get("/api/dashboard/summary", headers=H).json()
    assert r["registered_value"] is None and "tasks" in r["unavailable"]


def test_database_error_is_safe(monkeypatch):
    def boom(*a, **k):
        raise index.Unavailable("db")
    monkeypatch.setattr(index, "rows", boom)
    r = c.get("/api/dashboard/summary", headers=H)
    assert r.status_code == 503 and "Traceback" not in r.text


def test_health_rules():
    p = {"status": "active", "next_action": "x", "updated_at": "2026-11-15T00:00:00Z"}
    assert index.project_health(p, [], NOW)[0] == "green"
    assert index.project_health({**p, "next_action": None}, [], NOW)[0] == "orange"
    assert index.project_health({**p, "due_date": "2026-11-01"}, [], NOW)[0] == "red"
    assert index.project_health(p, [{"status": "open", "urgency": "must"}], NOW)[0] == "red"
    assert index.project_health({**p, "status": "paused"}, [], NOW)[0] == "grey"
